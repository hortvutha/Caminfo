package finder.khmer.sdbs.caminfo.adapter;

/**
 * Created by hort on 6/26/2015.
 */
public class GlobalValue {
    public final static String REQUEST_URL = "http://krg.sdbstechnology.com/responses/";

    public final static String SECURITY_CODE = "security_code";
    public final static String SECURITY_CODE_VALUE = "goodjob";

    public final static String REQUEST_CMD = "cmd";
}
